-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Nov 28, 2023 at 08:04 PM
-- Server version: 5.7.39
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `singer_id` int(11) NOT NULL,
  `album_name` varchar(255) NOT NULL,
  `songs` int(11) DEFAULT NULL,
  `release_year` int(11) DEFAULT NULL,
  `length` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `albums`
--

INSERT INTO `albums` (`singer_id`, `album_name`, `songs`, `release_year`, `length`) VALUES
(3, '1989', 19, 2014, '01:08:00'),
(1, '2020', 13, 2020, '01:03:00'),
(1, '7800 Fahrenheit', 10, 1985, '00:47:18'),
(1, 'Bon Jovi', 9, 1984, '00:38:33'),
(1, 'Bounce', 12, 2002, '00:49:06'),
(1, 'Burning Bridges', 10, 2015, '00:40:27'),
(1, 'Crush', 12, 2000, '00:58:20'),
(3, 'Evermore', 17, 2020, '01:09:00'),
(3, 'Fearless', 19, 2008, '01:19:00'),
(3, 'Folklore', 17, 2020, '01:07:00'),
(2, 'Gold Chain Cowboy', 10, 2021, '00:33:41'),
(8, 'Guts', 12, 2023, '00:39:18'),
(1, 'Have A Nice Day', 13, 2005, '00:53:50'),
(1, 'Keep The Faith', 12, 1992, '01:05:00'),
(1, 'Lost Highway', 12, 2007, '00:49:45'),
(3, 'Lover', 18, 2019, '01:01:00'),
(3, 'Midnights', 20, 2022, '01:09:00'),
(2, 'Never Enough', 15, 2023, '00:56:49'),
(1, 'New Jersey', 28, 1988, '02:18:00'),
(2, 'Probably Wrong', 10, 2017, '00:39:36'),
(3, 'Red', 22, 2012, '01:30:00'),
(3, 'Reputation', 15, 2017, '00:55:45'),
(1, 'Slippery When Wet', 10, 1986, '00:43:45'),
(8, 'Sour', 11, 2021, '00:34:46'),
(3, 'Speak Now', 20, 2010, '01:31:00'),
(7, 'Stories', 14, 2015, '00:54:40'),
(3, 'Taylor Swift', 15, 2006, '00:53:29'),
(1, 'The Circle', 12, 2009, '00:52:44'),
(2, 'The Limestone Kid', 11, 2015, '00:42:02'),
(1, 'These Days', 12, 1995, '01:03:00'),
(1, 'This House Is Not For Sale', 17, 2018, '01:08:00'),
(7, 'Tim', 12, 2019, '00:38:58'),
(7, 'True', 15, 2013, '01:17:00'),
(1, 'What About Now', 15, 2013, '01:05:00');

-- --------------------------------------------------------

--
-- Table structure for table `artists`
--

CREATE TABLE `artists` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `albums` varchar(255) DEFAULT NULL,
  `DOB` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `artists`
--

INSERT INTO `artists` (`id`, `name`, `genre`, `albums`, `DOB`) VALUES
(1, 'Bon Jovi', 'Rock', '15', '1962-03-02'),
(2, 'Parker McCollum', 'Country', '4', '1992-06-15'),
(3, 'Taylor Swift', 'Pop', '10', '1989-12-13'),
(7, 'Avicii', 'Electronic Pop', '3', '1989-09-08'),
(8, 'Olivia Rodrigo', 'Pop', '2', '2003-02-20');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`username`, `password`) VALUES
('admin', '$2y$10$P0ECzhQvxVQBDelGF.VKQ.6VyzF2JsQjytpbGRevvXeClI3BoeNNi'),
('ambender', '$2y$10$MYmAClYg2OsDTUUN8amq4eahUkSWe8N1X/IIVlbiCltY8YR4Ho07.'),
('newUser', '$2y$10$ujKtvLP/3sCjz9j5ZIHjH.p2uwq9RjECa1KX/YsVGYWXYv16nRRe.'),
('rbender', '$2y$10$H0GW.m13l5.s/ZmK4DdQY.sybdmu9wp6ZB7NL05/rqpGTPDTJLaTW'),
('testUser', '$2y$10$qIq/hIdER80/.LDQackJc.o4cKRNo330Lo8lw.FsgwYFCUQZKtZwy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`album_name`);

--
-- Indexes for table `artists`
--
ALTER TABLE `artists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artists`
--
ALTER TABLE `artists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
