<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Artist Search</title>
</head>
<body>
    <?php
    include "connect_db.php";

    session_start();
    if ($_SESSION["status"] == true){
        echo "<h2 class = 'w3-indigo'>Search for albums by musical artist on this page</h2>";

        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>";
        
        if($_SESSION["username"] == "admin"){
            echo "<a class='w3-bar-item w3-button' href='admin.php'>Admin</a>";  
        }
        echo"<a class='w3-bar-item w3-button w3-right' href='logout.php'>Log Out</a>"; 
        echo "</div>";
        


       echo "<h3>Search for an artist's albums using their Singer ID from the <a href = 'artists.php'>Musical Artists</a> page.</h3>"; 
       echo 
       "<form action =  'search.php' method = 'post'>
       
       <label for = 'id_search'>Singer ID: </label>
       <input class = 'w3-monospace' type = 'number' name = 'id_search' id = 'id_search'>
       <input class = 'w3-ripple' type = 'submit' value = 'Search'>
        </form>";

        $id_search = $_POST['id_search'];
        $id_search = (int)$id_search;
        
        echo "<table class = 'w3-table'>
                <thead>
                    <tr>
                        <th>Singer Name</th>
                        <th>Album Name</th>
                        <th>Number of Songs</th>
                        <th>Release Year</th>
                        <th>Length</th>
                    </tr>
                </thead>
                <tbody>";
                //$sql = "SELECT length FROM albums WHERE singer_id = $id_search";
                $sql = "SELECT name, album_name, songs, release_year, length
                        FROM artists A, albums B
                        WHERE A.id = B.singer_id
                        AND singer_id = $id_search";
                        
                $stmt = $pdo->prepare($sql);
                $stmt->execute();

                $results = $stmt->fetchAll();

                foreach($results as $row){
                        echo '<tr>
                            <td>'.$row['name'] .'</td>
                            <td>'.$row['album_name'] .'</td>
                            <td>'.$row['songs'] .'</td>
                            <td>'.$row['release_year'] .'</td>
                            <td>'.$row['length'] .'</td>                            
                            </tr>';
                }
                

                echo "</tbody><table>";


    }
    else{
        echo "<h1>Access not given</h1>";
        header("Location: login.php");
    }


    echo "<br><br>";
    ?>
</body>
<footer>
        <button class = 'w3-btn w3-blue'>
            <a href = 'logout.php'>Log out</a>
        </button>
</footer>
</html>