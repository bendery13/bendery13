<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Log Out</title>
</head>
<body>
<?php
   session_start();
    if ($_SESSION["status"] == true){
 
    echo "<h1 class = 'w3-red w3-row-padding'>Come back Soon!</h1> <br>";
    echo "<h3 class = 'w3-row-padding'>".$_SESSION["username"]. ", you are successfully logged out of the system.</h3>";

    session_destroy();
    $_SESSION['status'] = false;
    $_SESSION = null; 

    echo "<br><br>";
    echo "<form class = 'w3-row-padding' action = login.php method = 'post'>";
    echo "<input type = 'submit' value = 'Login'>";
    echo "</form>";
    }
    else{
        echo "<h1>Access not given</h1>";
        header("Location: login.php");
    }
?>

</body>
</html>
