<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Update an Artist</title>
</head>
<body>
    <?php

    session_start();
    include 'functions.php';
    include 'connect_db.php';
    
    if (($_SESSION["status"] == true) && ($_SESSION["username"] == "admin")){
        echo "<h1 class = 'w3-indigo'>Welcome to the Administration page</h1>";

        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>
        <a class='w3-bar-item w3-button' href='admin.php'>Admin</a>          
        </div>";

    }
    else if ($_SESSION["status"] == true) {
        echo "<h1>Access not given: Only administrators have access to this page</h1>";
        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>         
        </div>";
    }
    else{
        echo "<h1>Access not given</h1>";
        header("Location: login.php");
    }
    if (($_SESSION["status"] == true) && ($_SESSION["username"] == "admin")){
        echo "<h1 class = 'w3-center w3-teal w3-cursive'>Update an Artist's Information</h1> <br>";
        echo "<p class = 'w3-center'>Update an artist's information using their singer ID</p>";
        echo "<form class = 'w3-center w3-input' action = 'update_artist.php' method = 'post'>
        
        <label for = 'singer_id'>Singer ID: </label>
        <input class = 'w3-monospace' type = 'number' name = 'singer_id' id = 'singer_id' required>
        <br>

        <label for = 'name'>Name: </label>
        <input class = 'w3-monospace' type = 'text' name = 'name' id = 'name' required>
        <br>

        <label for='genre'>Genre:</label>
        <input class = 'w3-monospace' type='text' id = 'genre' name= 'genre' required>
        <br>

        <label for = 'albums'>Albums: </label>
        <input class = 'w3-monospace' type = 'number' name = 'albums' id = 'albums'>
        <br>

        <label for='birthdate'>Date of Birth:</label>
        <input class = 'w3-monospace' type='text' id = 'birthdate' name= 'birthdate'>
        <br>

        <label>Enter date of birth in format (YYYY-MM-DD)</label>
        <br> 
        <br>
        <input class = 'w3-ripple' type='submit' value = 'Update'>
    </form>";

    $singer_id = (int)$_POST['singer_id'];
    $names = $_POST['name'];
    $genre = $_POST['genre'];
    $album = (int)$_POST['albums'];
    $birthdate = $_POST['birthdate'];

    $sql = "UPDATE artists
            SET name = '$names', genre = '$genre', albums = '$album', DOB = '$birthdate'
            WHERE id = '$singer_id'";

    $statement=$pdo->prepare($sql);
    $statement->execute();
        echo "<h4 class = 'w3-text-green w3-center'>Updated Successfully</h4>";
        
    }


    
    ?>
</body>
<footer>
    <button class = 'w3-btn w3-blue'>
        <a href = 'logout.php'>Log out</a>
    </button>
</footer>
</html>