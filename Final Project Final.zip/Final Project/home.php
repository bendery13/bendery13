<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Home</title>
</head>
<body>
    <?php
    session_start();
    include 'connect_db.php';

    if ($_SESSION["status"] == true){
        echo "<h2 class = 'w3-light-blue'>Welcome ".$_SESSION["username"]. " to the website </h2>";
        
        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>";
        
        if($_SESSION["username"] == "admin"){
            echo "<a class='w3-bar-item w3-button' href='admin.php'>Admin</a>";  
        }
        echo "<a class='w3-bar-item w3-button w3-right' href='logout.php'>Log Out</a></div>";
        
        echo "<p>This is the home page of the website.<br>
                On this website, you will have access to viewing information about different musican's albums.";

 
                $sql = "SELECT * FROM artists";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();

                $result = $stmt->fetchAll();        
                echo "<ul>";

                foreach($result as $row){
                    echo "<li>".$row['name']."</li>";
                    }
                echo "</ul>";

                echo "Click from the bar above what information you would like to view.
        
        </p>";

    }
    else{
        echo "<h1>Access not given</h1>";
        header("Location: login.php");
    }
    ?>
</body>
<footer>
    <button class = 'w3-btn w3-blue'>
        <a href = 'logout.php'>Log out</a>
    </button>
</footer>
</html>