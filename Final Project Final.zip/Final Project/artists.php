<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Musical Artists</title>
</head>
<body>
    <?php
    include 'connect_db.php';

    session_start();
    if ($_SESSION["status"] == true){
        echo "<h2 class = 'w3-indigo'>This is the Artists' Page</h2>";

        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>";
        
        if($_SESSION["username"] == "admin"){
            echo "<a class='w3-bar-item w3-button' href='admin.php'>Admin</a>";  
        }
        echo"<a class='w3-bar-item w3-button w3-right' href='logout.php'>Log Out</a>";
        echo "</div>";
        
        echo "<div>";
        echo '<table class = w3-table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Genre</th>
                    <th>Albums</th>
                    <th>Date of Birth</th>
                </tr>
            </thead>
            <tbody>';
            

        $sql = "SELECT * FROM artists";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();

                $result = $stmt->fetchAll();

                foreach($result as $row){
                        echo '<tr>
                            <td>'.$row['id'] .'</td>
                            <td>'.$row['name'] .'</td>
                            <td>'.$row['genre'] .'</td>
                            <td>'.$row['albums'] .'</td>
                            <td>'.$row['DOB'] .'</td>   
                        </tr>';
                    }
            echo "</div>";      
    }
    else{
        echo "<h1>Access not given</h1>";
        header("Location: login.php");
    }

?>
</body>
<footer>
</footer>
</html>