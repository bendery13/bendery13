<?php
//This page processes the login of an already existing user
include 'functions.php';

$dsn="mysql:host=localhost;dbname=project";

try{
    $pdo= new PDO($dsn, "root", "root");
}
catch(PDOException $e){
    die("Connection error: ". $e->getMessage());
}

session_start();
$_SESSION["status"] = false;

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $username=$_POST['username'];
    $password=$_POST['password'];


    if(login_user($username, $password)){
        $_SESSION["username"] = $username;
        $_SESSION["status"] = true;
        
        header("Location: home.php");
    }
}

?>