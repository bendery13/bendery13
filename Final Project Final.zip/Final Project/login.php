<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Login Page</title>
</head>
<body>
    <h1 class = "w3-center w3-blue w3-cursive">Login</h1>
    <br>
    <form class = "w3-center" action = "process_login.php" method = "post">
        <label for = "username">Username: </label>
        <input class = "w3-monospace" type = "text" name = "username" id = "username" required>
        <br>
        <label for="password">Password:</label>
        <input class = "w3-monospace" type="password" id="password" name="password" required>
        <br> <br>
        <input class = "w3-ripple" type="submit" value = "Login">
    </form>

    <form class = "w3-center w3-input" action = "register.php" method = "post">
    <p>If you are a new user, click here to register:</p>
    <input type="submit" value = "Register"> 
    <p>  </p>
    </form>
</body>
<footer>
    <p>&copy 2023 Ryan Bender</p>
</footer>
</html>