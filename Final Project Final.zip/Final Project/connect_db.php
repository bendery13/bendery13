<?php

    $dsn="mysql:host=localhost;dbname=project";

    try{
        $pdo= new PDO($dsn, "root", "root");
    }
    catch(PDOException $e){
        die("Connection error: ". $e->getMessage());
    }


?>