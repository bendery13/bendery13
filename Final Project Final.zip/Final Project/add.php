<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Add a User</title>
</head>
<body>
    <?php

    session_start();
    include 'functions.php';
    include 'connect_db.php';

    if (($_SESSION["status"] == true) && ($_SESSION["username"] == "admin")){
        echo "<h1 class = 'w3-indigo'>Welcome to the Administration page</h1>";

        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>
        <a class='w3-bar-item w3-button' href='admin.php'>Admin</a>          
        </div>";

    }
    else if ($_SESSION["status"] == true) {
        echo "<h1>Access not given: Only administrators have access to this page</h1>";
        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>         
        </div>";
    }
    else{
        echo "<h1>Access not given</h1>";
        header("Location: login.php");
        
    }
    if (($_SESSION["status"] == true) && ($_SESSION["username"] == "admin")){
        echo "<h1 class = 'w3-center w3-green w3-cursive'>Add a new user</h1> <br>";

        echo "<form class = 'w3-center w3-input' action = 'add.php' method = 'post'>
            <label for = 'username'>Username: </label>
            <input class = 'w3-monospace' type = text' name = 'username' id = 'username' required>
            <br>
            <label for='password'>Password:</label>
            <input class = 'w3-monospace' type='password' id = 'password' name= 'password' required>
            <br> <br>
            <p class = 'w3-sans-serif w3-center'>
                <h4>Password Requirements</h4>
                - Must be 7-12 characters<br>
                - Must include a capital letter
            </p>
            <br>
            <input class = 'w3-ripple' type='submit' value = 'Add'>
        </form>";
            $username = $_POST['username'];
            $password = $_POST['password'];

        if (check_user($username,$password)){
            $sql = "INSERT INTO registration(username,password) VALUES (:username,:password)";
            $statement=$pdo->prepare($sql);
            $statement->execute(['username' => $username, 'password' => $password]);
            echo "<h2 class = 'w3-center w3-text-green'>User added</h2>"; 
        }
    }
    ?>
</body>
<footer>
    <button class = 'w3-btn w3-blue'>
        <a href = 'logout.php'>Log out</a>
    </button>
</footer>
</html>