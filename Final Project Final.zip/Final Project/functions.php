<!DOCTYPE html>

<head>
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>  

<?php
function check_user($username, $password){
    global $pdo;
    $sql="SELECT username FROM registration WHERE username ='$username'";
    $statement=$pdo->prepare($sql);
    $statement->execute();
        
    if($statement->rowCount() == 0){
        return check_password($password);
    }
    else{
        echo "<h4 class = 'w3-text-red w3-center'>Username already taken</h4>";
        return false;
    }

}
function check_password($password){
    if(strlen($password) <= '12' && strlen($password) >= '7'){
        if ($password != strtolower($password)){
            return true;
        }
        else{
            echo "<h4 class = 'w3-text-red w3-center'>Password must include a capital letter</h4>";
            return false;
        }
    }
    else{
        echo "<h4 class = 'w3-text-red w3-center'>Password length not valid</h4>";
        return false;
    }
}
function login_user($username, $password){
    global $pdo;
    
    $sql= "SELECT username, password FROM registration WHERE username = ?";

    $statement=$pdo->prepare($sql);
    $statement->execute(["$username"]);

    $info = $statement->fetch();

    $hashedPassword = $info['password'];

    if(password_verify($password, $hashedPassword)){
        return true;
    }
    else{
        echo "<h4 class = 'w3-text-red w3-center'>Password is incorrect</h4>";
        return false;
    }
    
    
    
    // $sql= "SELECT username, password FROM registration WHERE username = '$username' and password = '$password'";
    // $statement=$pdo->prepare($sql);
    // $statement->execute();
        
    // if($statement->rowCount() == 1){
    //     echo "Login Found";
    //     return true;
    // }
    //$sql= "SELECT username FROM registration WHERE username = '$username'";
    // $statement=$pdo->prepare($sql);
    // $statement->execute();
    //     if($statement->rowCount() == 1){
    //         echo "<h4 class = 'w3-text-red w3-center'>Invalid Password</h4>";
    //         return false;
    //     }
    //     else{
    //         echo "<h4 class = 'w3-text-red w3-center'>User not found</h4>";
    //         return false;
    //     }
    
}
?>
</body>