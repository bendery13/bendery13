<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Registration</title>
</head>
<body>
   <h1 class = "w3-center w3-cyan w3-cursive">Register as a new user</h1>
   <br>
    <form class = "w3-center w3-input" action = "process_register.php" method = "post">
        <label for = "username">Username: </label>
        <input class = "w3-monospace" type = "text" name = "username" id = "username" required>
        <br>
        <label for="password">Password:</label>
        <input class = "w3-monospace" type="password" id="password" name="password" required>
        <br> <br>
        <p class = 'w3-sans-serif w3-center'>
            <h4>Password Requirements</h4>
            - Must be 7-12 characters<br>
            - Must include a capital letter
        </p>
        <br>
        <input class = "w3-ripple " type="submit" value = "Register">
    </form>
 
</body>
<footer>
    <p>&copy 2023 Ryan Bender</p>
</footer>
</html>