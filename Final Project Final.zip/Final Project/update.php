<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Update a user</title>
</head>
<body>
    <?php

    session_start();
    include 'functions.php';
    include 'connect_db.php';
    
    if (($_SESSION["status"] == true) && ($_SESSION["username"] == "admin")){
        echo "<h1 class = 'w3-indigo'>Welcome to the Administration page</h1>";

        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>
        <a class='w3-bar-item w3-button' href='admin.php'>Admin</a>          
        </div>";

    }
    else if ($_SESSION["status"] == true) {
        echo "<h1>Access not given: Only administrators have access to this page</h1>";
        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>         
        </div>";
    }
    else{
        echo "<h1>Access not given</h1>";
        header("Location: login.php");
    }
    if (($_SESSION["status"] == true) && ($_SESSION["username"] == "admin")){
        echo "<h1 class = 'w3-center w3-teal w3-cursive'>Update a user</h1> <br>";
        echo "<p class = 'w3-center'>Update a user's password by entering in the account's username followed by its new password</p>";
        echo "<form class = 'w3-center w3-input' action = 'update.php' method = 'post'>
            <label for = 'username'>Username: </label>
            <input class = 'w3-monospace' type = text' name = 'username' id = 'username' required>
            <br>
            <label for = 'password'>New Password: </label>
            <input class = 'w3-monospace' type = text' name = 'new_password' id = 'new_password' required>
            <br>
            <label for = 'confirm_password'>Confirm Password: </label>
            <input class = 'w3-monospace' type = text' name = 'confirm_password' id = 'confirm_password' required>
            <br><br>
            <input class = 'w3-ripple' type='submit' value = 'Update'>
        </form>";
        
        $user = $_POST['username'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        if($new_password === $confirm_password){
                $sql = "UPDATE registration
                SET password = '$new_password'
                WHERE username = '$user' ";

                $statement=$pdo->prepare($sql);
                $statement->execute();
            }
        else{
            echo "<h4 class = 'w3-text-red w3-center'>Passwords must match</h4>";
        }

    }
    
    ?>
</body>
<footer>
    <button class = 'w3-btn w3-blue'>
        <a href = 'logout.php'>Log out</a>
    </button>
</footer>
</html>