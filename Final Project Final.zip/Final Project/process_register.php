<?php
//This page registers a new user into the database
session_start();
$_SESSION["status"] = false;
//Connecting to database
include 'functions.php';

$dsn="mysql:host=localhost;dbname=project";

try{
    $pdo= new PDO($dsn, "root", "root");
}
catch(PDOException $e){
    die("Connection error: ". $e->getMessage());
}

//Retrieving input
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $username=$_POST['username'];
    $password=$_POST['password'];
}

    if (check_user($username,$password)){
        $sql = "INSERT INTO registration(username,password) VALUES (:username,:password)";
         
        $statement=$pdo->prepare($sql);
        $pwdHashed = password_hash($password,PASSWORD_BCRYPT);

        $statement->bindParam(':username', $username);
        $statement->bindParam(':password', $pwdHashed);


        $statement->execute();

        $_SESSION["username"] = $username;
        $_SESSION["status"] = true;
        echo "User added";
        header("Location: home.php");
    }
 
?>