<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet"href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="icon" href="favicon.png">
    <title>Administration</title>
</head>
<body>
    <?php
    
    session_start();
    include 'connect_db.php';
    if (($_SESSION["status"] == true) && ($_SESSION["username"] == "admin")){
        echo "<h1 class = 'w3-indigo'>Welcome to the Administration page</h1>";

        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>
        <a class='w3-bar-item w3-button' href='admin.php'>Admin</a>
        <a class='w3-bar-item w3-button w3-right' href='logout.php'>Log Out</a>            
        </div>";

    }
    else if ($_SESSION["status"] == true) {
        echo "<h1>Access not given: Only administrators have access to this page</h1>";
        echo "<div class='w3-bar w3-black'>
        <a class='w3-bar-item w3-button' href='home.php'>Home</a>
        <a class='w3-bar-item w3-button' href='artists.php'>Musical Artists</a>
        <a class='w3-bar-item w3-button' href='search.php'>Artist Search</a>
        <a class='w3-bar-item w3-button w3-right' href='logout.php'>Log Out</a>          
        </div>";
    }
    else{
        echo "<h1>Access not given</h1>";
        header("Location: login.php");
        
    }

    ?>
    <?php  
    if (($_SESSION["status"] == true) && ($_SESSION["username"] == "admin")){
        echo "<div class = 'w3-container'>
            <br>
            <button class = 'w3-btn w3-blue'>
                <a href = 'add.php'>Add User</a>
            </button>
            <button class = 'w3-btn w3-blue'>
                <a href = 'delete.php'>Delete User</a>
            </button>
            <button class = 'w3-btn w3-blue'>
                <a href = 'update.php'>Update User Info</a>
            </button>
            <button class = 'w3-btn w3-blue'>
                <a href = 'search_user.php'>Search User</a>
            </button>
            
            <br>
            <table class = 'w3-table'>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Password</th>
                    </tr>
                </thead>
                <tbody>";
                
                $sql = "SELECT * FROM registration";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();

                $result = $stmt->fetchAll();

                foreach($result as $row){
                        echo '<tr>
                            <td>'.$row['username'] .'</td>
                            <td>'.$row['password'] .'</td>
                            
                        </tr>';
                }
                    
                echo '</tbody></table>';  
            echo "<br>
                <button class = 'w3-btn w3-blue'>
                    <a href = 'add_artist.php'>Add Artists</a>
                </button>
                <button class = 'w3-btn w3-blue'>
                    <a href = 'delete_artist.php'>Delete Artists</a>
                </button>
                <button class = 'w3-btn w3-blue'>
                    <a href = 'update_artist.php'>Update Artists</a>
                </button>
                <button class = 'w3-btn w3-blue'>
                    <a href = 'search.php'>Search Artists</a>
                </button>
                
                <br><br>";
               
        echo '<table class = w3-table>
            <thead>
                <tr>
                    <th>id</th>
                    <th>Name</th>
                    <th>Genre</th>
                    <th>Albums</th>
                    <th>Date of Birth</th>
                </tr>
            </thead>
            <tbody>';
            

        $sql = "SELECT * FROM artists";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();

                $result = $stmt->fetchAll();

                foreach($result as $row){
                        echo '<tr>
                            <td>'.$row['id'] .'</td>
                            <td>'.$row['name'] .'</td>
                            <td>'.$row['genre'] .'</td>
                            <td>'.$row['albums'] .'</td>
                            <td>'.$row['DOB'] .'</td>   
                        </tr>';
                    }
            echo "</div>";    
            }     
            ?>

    
</body>
<footer>
        
</footer>
</html>